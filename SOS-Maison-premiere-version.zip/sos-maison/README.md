# SOS Maison — première version

Application web mobile en français, installable comme une application (PWA) sur Android et iPhone.

## Fichiers
- `index.html` : interface et diagnostics guidés
- `manifest.webmanifest` : informations d'installation
- `sw.js` : mise en cache pour un usage hors connexion après première visite
- `icon.svg` : icône

## Mise en ligne gratuite
Décompressez le ZIP puis publiez le contenu du dossier sur un hébergeur statique gratuit (par exemple GitHub Pages). Aucun compte Netlify payant ni crédit d'agent n'est nécessaire pour ces fichiers statiques.

## Installation
- Android : ouvrir l'adresse publiée dans Chrome, menu ⋮, « Installer l'application » ou « Ajouter à l'écran d'accueil ».
- iPhone : ouvrir dans Safari, bouton Partager, « Sur l'écran d'accueil ».

## Important
Les conseils sont généraux et ne remplacent pas un professionnel. En cas de danger immédiat, appeler les secours. En France : 112, 18, 15, 17. Le 114 est accessible par SMS/application pour les personnes concernées.
